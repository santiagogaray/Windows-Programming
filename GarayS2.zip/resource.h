//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Presidents.rc
//
#define IDD_PRESIDENTS_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDB_BITMAP1                     129
#define IDC_DONE                        1000
#define IDC_INPUT_FILE                  1001
#define IDC_BROWSE                      1003
#define IDC_OPEN                        1004
#define IDC_PRESIDENTS_LB               1005
#define IDC_LENGTH_MSGE                 1006
#define IDC_INITIALS_MSGE               1007
#define IDC_FIRST                       1008
#define IDC_SECOND                      1009
#define IDC_LAST                        1010
#define IDC_UPDATE                      1011
#define IDC_SAVE                        1012

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
